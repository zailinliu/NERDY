package com.dw.teamproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeamprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
