package com.dw.teamproject.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dw.teamproject.model.Acc;

public interface AccRepository extends JpaRepository<Acc, Long> {

}
