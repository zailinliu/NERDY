package com.dw.teamproject.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dw.teamproject.model.Lookbook;

public interface LookbookRepository extends JpaRepository<Lookbook, Long> {

}
