package com.dw.teamproject.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dw.teamproject.model.MBSlide;

public interface MBSlideRepository extends JpaRepository<MBSlide, Long> {

}
